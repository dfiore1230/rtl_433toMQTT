#!/bin/bash

echo 'Please use "rtl_433 [-s <samplerate>] -w <output>.sr -r <input>.cu8"'
